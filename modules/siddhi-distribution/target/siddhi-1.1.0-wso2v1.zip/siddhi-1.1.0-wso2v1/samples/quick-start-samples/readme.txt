
ReadMe on running the samples
=============================

1. run "ant" from "samples" (this) directory to build the samples
2. run "ant simpleFilter" to run the simple filter sample
3. run "ant timeWindow" to run the time window sample
4. run "ant patternProcessor" to run the pattern processor sample
